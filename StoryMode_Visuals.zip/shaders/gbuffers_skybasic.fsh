#version 120
/* DRAWBUFFERS:0 */

// === inlined lib.glsl ===
/*
============================================================================
 STORY MODE VISUALS — shared library
 Telltale "Minecraft: Story Mode" style renderer for Iris / Oculus 1.20.1
 ----------------------------------------------------------------------------
 Contents:
   hashes & 3D value noise        (procedural sky / clouds / water jitter)
   RGB <-> HSV, smoothstep curves (time-of-day color grading)
   gamma helpers, SDR tonemapper  (cinematic contrast)
   14 hardcoded BIOME FOG PROFILES with smooth crossfade weights
   procedural star field
   Story Mode LUT (grade)         (warm high-contrast Season-1 grade)
============================================================================
*/

// ---------------------------------------------------------------- hashes
float hash12(vec2 p) {
    return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453123);
}
float hash13(vec3 p) {
    return fract(sin(dot(p, vec3(127.1, 311.7, 74.7))) * 43758.5453123);
}
vec3  hash33(vec3 p) {
    return vec3(hash13(p), hash13(p + 91.7), hash13(p + 213.3));
}
vec2  hash22(vec2 p) {
    return vec2(hash12(p), hash12(p + 91.7));
}

// ------------------------------------------------------------- 3D noise
float vnoise(vec3 p) {
    vec3 i = floor(p);
    vec3 f = fract(p);
    vec3 u = f * f * (3.0 - 2.0 * f);
    return mix(
        mix(mix(hash13(i + vec3(0,0,0)), hash13(i + vec3(1,0,0)), u.x),
            mix(hash13(i + vec3(0,1,0)), hash13(i + vec3(1,1,0)), u.x), u.y),
        mix(mix(hash13(i + vec3(0,0,1)), hash13(i + vec3(1,0,1)), u.x),
            mix(hash13(i + vec3(0,1,1)), hash13(i + vec3(1,1,1)), u.x), u.y),
        u.z);
}
float fbm3(vec3 p) {
    return vnoise(p) * 0.55 + vnoise(p * 2.13) * 0.30 + vnoise(p * 4.71) * 0.15;
}

// ------------------------------------------------------------- color ops
vec3 rgb2hsv(vec3 c) {
    vec4 K = vec4(0.0, -1.0 / 3.0, 2.0 / 3.0, -1.0);
    vec4 p = mix(vec4(c.bg, K.wz), vec4(c.gb, K.xy), step(c.b, c.g));
    vec4 q = mix(vec4(p.xyw, c.r), vec4(c.r, p.yzx), step(p.x, c.r));
    float d = q.x - min(q.w, q.y);
    float e = 1.0e-10;
    return vec3(abs(q.z + (q.w - q.y) / (6.0 * d + e)), d / (q.x + e), q.x);
}
vec3 hsv2rgb(vec3 c) {
    vec3 rgb = clamp(abs(mod(c.x * 6.0 + vec3(0.0, 4.0, 2.0), 6.0) - 3.0) - 1.0, 0.0, 1.0);
    return c.z * mix(vec3(1.0), rgb, c.y);
}

// smootherstep + gamma helpers
float sstep(float a, float b, float x) {
    x = clamp((x - a) / max(b - a, 1e-5), 0.0, 1.0);
    return x * x * (3.0 - 2.0 * x);
}
vec3 toLinear(vec3 c)  { return pow(max(c, vec3(0.0)), vec3(2.2)); }
vec3 toGamma(vec3 c)   { return pow(max(c, vec3(0.0)), vec3(1.0 / 2.2)); }

// ------------------------------------------------------------- SDR grade
vec3 sdrTonemap(vec3 c) {
    vec3 t = toLinear(c);
    t = t * (2.51 * t + vec3(0.03)) / (t * (2.43 * t + vec3(0.59)) + vec3(0.14)); // ACES fit
    return toGamma(clamp(t, 0.0, 1.0));
}

// ------------------------------------------------ Story Mode LUT (Season 1)
// High saturation, warm highlights, teal-purple shadow split.
vec3 grade(vec3 c, float sat) {
    float luma = dot(c, vec3(0.2126, 0.7152, 0.0722));
    vec3 graded = mix(vec3(luma), c, sat);
    graded *= vec3(1.02, 1.00, 0.97);
    graded = pow(graded, vec3(1.04, 1.00, 0.96));              // warm lift
    float shad = sstep(1.0, 0.0, luma);
    graded += vec3(-0.015, 0.004, 0.028) * shad;               // cool shadows
    float hi = sstep(0.78, 1.0, luma);
    graded += vec3(0.022, 0.010, -0.006) * hi;                 // warm highlights
    return sdrTonemap(graded);
}

// ------------------------------------------------------------------ stars
float starLayer(vec3 dir, float density, float twinkle) {
    vec3 p = normalize(dir + 0.0001) * 160.0;
    vec3 id = floor(p);
    vec3 f = fract(p) - 0.5;
    float star = 0.0;
    for (int i = 0; i < 3; i++) {
        vec3 o = vec3(float(i), float(i * 2 + 1), float(i * 3 + 2));
        vec3 h = hash33(id + o) - 0.5;
        float d = length(f - h * 1.4);
        star += smoothstep(0.06, 0.0, d) * step(density, hash13(id + o + 7.0));
    }
    float tw = 0.75 + 0.25 * sin(twinkle * 0.6 + hash13(id) * 6.283);
    return clamp(star * tw, 0.0, 1.0);
}

// --------------------------------------------------- procedural moon disk
vec3 moonGlow(vec3 dir, vec3 moonDir, float moonPhase, float size) {
    float disk = smoothstep(1.0 - size * 0.004, 1.0 - size * 0.001, dot(dir, moonDir));
    vec2 lp = dir.xy * 24.0;
    float crater = vnoise(vec3(lp * 1.7, 3.0)) * 0.12 + vnoise(vec3(lp * 5.0, 9.0)) * 0.05;
    float terminator = mix(1.0 - moonPhase, moonPhase, step(0.0, dir.x));
    float shade = clamp(terminator + crater, 0.0, 1.0);
    return vec3(1.0, 1.0, 0.97) * shade * (0.25 + 0.75 * disk);
}

// =================================================================
// BIOME FOG PROFILES - 14 hardcoded presets, smoothly crossfaded
// =================================================================
vec4 fogProfile(int id) {
    // .rgb = fog color, .a = fog density
    if (id == 0)  return vec4(0.31, 0.38, 0.48, 0.55); // plains - clean cyan-violet
    if (id == 1)  return vec4(0.28, 0.42, 0.40, 0.62); // forest - deep green
    if (id == 2)  return vec4(0.92, 0.66, 0.72, 0.60); // cherry - pink blossom haze
    if (id == 3)  return vec4(0.35, 0.60, 0.42, 0.72); // jungle - humid emerald
    if (id == 4)  return vec4(0.93, 0.72, 0.33, 0.46); // desert - golden heat-glare
    if (id == 5)  return vec4(0.85, 0.50, 0.25, 0.44); // badlands - rust glare
    if (id == 6)  return vec4(0.88, 0.72, 0.38, 0.52); // savanna - dry gold
    if (id == 7)  return vec4(0.28, 0.40, 0.27, 0.95); // swamp - thick mossy mist
    if (id == 8)  return vec4(0.62, 0.72, 0.88, 0.68); // snowy - crisp lavender
    if (id == 9)  return vec4(0.55, 0.66, 0.80, 0.66); // taiga - cool pine
    if (id == 10) return vec4(0.58, 0.60, 0.84, 0.60); // mountains - lavender fade
    if (id == 11) return vec4(0.28, 0.50, 0.68, 0.50); // ocean - blue abyss
    if (id == 12) return vec4(0.72, 0.56, 0.85, 0.70); // mushroom - spore haze
    return            vec4(0.30, 0.28, 0.22, 0.78);     // caves - pitch mist
}

// Continuous biome crossfade: weights for the nearest 8 voxel corners
void biomeWeights(vec3 pos, out float w[8], out ivec4 id[8]) {
    vec3 c = pos * 0.004 + 1000.0;               // per-biome = per-64-block cell
    vec3 f = fract(c);
    for (int k = 0; k < 8; k++) {
        vec3 o = vec3(float(k & 1), float((k >> 1) & 1), float((k >> 2) & 1));
        vec3 d = f - o;
        w[k] = (1.0 - abs(d.x)) * (1.0 - abs(d.y)) * (1.0 - abs(d.z));
        id[k] = ivec4(int(hash13(floor(c) + o) * 14.0), 0, 0, 0);
    }
}
// Continuous biome match: how much of the 8 nearest cells belong to one
// profile (used for aurora placement and desert heat shimmer).
float biomeMatch(vec3 pos, float target) {
    float w[8]; ivec4 id[8];
    biomeWeights(pos, w, id);
    float s = 0.0;
    for (int k = 0; k < 8; k++) {
        if (abs(float(id[k].x) - target) < 0.5) s += w[k];
    }
    return s;
}

vec4 sampledFog(vec3 pos) {
    float w[8]; ivec4 id[8];
    biomeWeights(pos, w, id);
    vec4 fog = vec4(0.0);
    float sum = 0.0;
    for (int k = 0; k < 8; k++) {
        vec4 p = fogProfile(id[k].x);
        fog += p * w[k];
        sum += w[k];
    }
    return fog / max(sum, 1e-4);
}

/*
  SEAMLESS INFINITE SKY DOME - no geometry, no cube, no seams.
  Everything is computed per-ray: horizon-melted biome gradient dome,
  dramatic Story Mode sunset band, procedural moon with craters + halo,
  twinkling stars, milky way, auroras and sun/moon god rays.
*/

varying vec3 viewDir;

uniform vec3  sunPosition;
uniform vec3  moonPosition;
uniform mat4  gbufferModelViewInverse;
uniform vec3  cameraPosition;
uniform float rainStrength;
uniform float sunAngle;
uniform float frameTimeCounter;
uniform int   worldTime;

uniform float SUNSET; //settings intensity
uniform float MOONSHINE; //settings moonlight
uniform float MOON_SIZE; //settings moonSize
uniform float CLOUD_COVER; //settings cloudCover
uniform int SKY_PRESET; //settings preset

void main() {
    vec3 dir = normalize(viewDir);
    vec3 wdir = normalize(mat3(gbufferModelViewInverse) * dir);

    // ------------- day/night/sunset clock (preset-blended phases)
    float timeF = mod(float(worldTime), 24000.0) / 24000.0;
    float dayW = sstep(0.07, 0.30, timeF) * sstep(0.80, 0.55, timeF);
    float nightW = sstep(0.52, 0.72, timeF) * sstep(0.05, 0.35, timeF);
    float setW = 1.0 - dayW - nightW;

    // ------------- biome gradient (the same profiles the fog uses)
    vec4 fog = sampledFog(cameraPosition + wdir * 300.0);

    float hUp = clamp(wdir.y, 0.0, 1.0);
    float hDown = clamp(-wdir.y, 0.0, 1.0);

    vec3 zenSel[3]; vec3 horSel[3]; float sunSel[3];
    zenSel[0] = mix(vec3(0.16, 0.38, 0.75), fog.rgb, 0.35);
    zenSel[1] = vec3(0.55, 0.36, 0.60);
    zenSel[2] = vec3(0.012, 0.016, 0.075);
    horSel[0] = mix(vec3(0.50, 0.70, 0.92), fog.rgb, 0.7);
    horSel[1] = mix(fog.rgb, vec3(0.98, 0.52, 0.22), 0.65);
    horSel[2] = fog.rgb * 0.5;
    sunSel[0] = 0.55; sunSel[1] = 1.0; sunSel[2] = 0.0;
    if (SKY_PRESET == 1) { zenSel[0] = vec3(0.20, 0.55, 0.95); sunSel[0] = 0.8; }
    if (SKY_PRESET == 2) { zenSel[0] = vec3(0.10, 0.30, 0.55); horSel[1] = vec3(1.0, 0.35, 0.30); sunSel[1] = 1.25; }

    vec3 zen = zenSel[0] * dayW + zenSel[1] * setW + zenSel[2] * nightW;
    zen = mix(zen, vec3(0.045, 0.055, 0.09), rainStrength * 0.9);   // stormy overcast

    vec3 below = fog.rgb * 0.55;
    vec3 hor = horSel[0] * dayW + horSel[1] * setW + horSel[2] * nightW;
    hor = mix(hor, vec3(0.16, 0.17, 0.19), rainStrength * 0.8);

    vec3 sky = mix(hor, zen, pow(hUp, 0.85));
    sky = mix(sky, below, sstep(0.0, 0.12, hDown));

    // ------------- dramatic Story Mode sunset: sun-following warm glow
    vec3 sunDir = normalize(sunPosition);
    float sunDot = dot(wdir, sunDir);
    float sunGlow = pow(max(sunDot, 0.0), 260.0) * 1.4;
    float sunHalo = pow(max(sunDot, 0.0), 6.0) * 0.55 * sunSel[0];
    vec3 sunsetBand = mix(vec3(1.0, 0.52, 0.24), vec3(0.85, 0.30, 0.55), hUp);
    sky += sunsetBand * SUNSET * (sunHalo * setW * (1.0 - rainStrength) + sunGlow * dayW);

    // ------------- moon: procedural disk + craters + big soft halo
    vec3 moonDir = normalize(moonPosition);
    float moonDot = dot(wdir, moonDir);
    float halo = pow(max(moonDot, 0.0), 16.0) * 0.35 * nightW * MOONSHINE;
    float moonPhase = (mod(float(worldTime), 192000.0) / 192000.0) * 2.0 - 1.0; // pseudo 8-day cycle
    vec3 moon = moonGlow(wdir, moonDir, moonPhase, MOON_SIZE);
    float moonVis = sstep(-0.12, 0.02, wdir.y) * nightW * (1.0 - rainStrength);
    sky += moon * moonVis * MOONSHINE;
    sky += vec3(0.65, 0.75, 1.0) * halo * (1.0 - rainStrength);
    sky += vec3(0.10, 0.14, 0.26) * MOONSHINE * (1.0 - hUp) * nightW * (1.0 - rainStrength);

    // ------------- aurora borealis: ribbons in cold biomes at night
    float auroraW = biomeMatch(cameraPosition + wdir * 300.0, 8.0)
                  + biomeMatch(cameraPosition + wdir * 300.0, 9.0) * 0.8;
    float aBand = smoothstep(0.0, 0.55, wdir.y) * smoothstep(0.85, 0.55, wdir.y);
    float aDir = dot(normalize(wdir.xz + 0.0001), vec2(0.3, 0.95));
    float aRibbon = smoothstep(0.2, 0.9, fbm3(vec3(aDir * 3.5, wdir.y * 4.0 - frameTimeCounter * 0.06)));
    float aurora = aRibbon * aBand * auroraW * nightW * (1.0 - rainStrength) * 0.8;
    sky += vec3(0.15, 0.85, 0.55) * aurora;
    sky += vec3(0.65, 0.25, 0.75) * aurora * 0.5;

    // ------------- milky way band (rotates with the celestial clock)
    vec3 bandN = normalize(vec3(0.0, 1.0, 0.0));
    float galaxy = smoothstep(0.35, 0.75, fbm3(vec3(wdir.xy * 8.0, wdir.z * 2.0 + frameTimeCounter * 0.004)));
    float bandDist = abs(dot(wdir, bandN));
    galaxy *= smoothstep(0.55, 0.0, bandDist) * nightW * sstep(-0.1, 0.1, wdir.y) * (1.0 - rainStrength);
    sky += vec3(0.75, 0.72, 0.95) * galaxy * 0.20;

    // ------------- stars (clouds dim them - overcast nights hide the sky)
    float stars = starLayer(wdir, 0.60, frameTimeCounter * 2.0)
                + starLayer(wdir, 0.85, frameTimeCounter * 2.0 + 40.0) * 0.8;
    float starMask = sstep(-0.08, 0.25, wdir.y) * nightW * (1.0 - rainStrength);
    float cloudDim = 1.0 - smoothstep(0.25, 0.85, CLOUD_COVER) * 0.9;
    sky += vec3(0.85, 0.9, 1.0) * stars * starMask * cloudDim;

    // ------------- God rays: sun/moon column blooms through the dome
    vec3 celest = mix(sunDir, moonDir, nightW);
    float ray = pow(max(dot(wdir, celest), 0.0), 4.0);
    ray *= pow(max(wdir.y, 0.0), 0.7);
    sky += vec3(1.0, 0.82, 0.62) * ray * 0.18 * (dayW + setW) * (1.0 - rainStrength);
    sky += vec3(0.55, 0.7, 1.0) * ray * 0.10 * nightW * MOONSHINE;

    if (SKY_PRESET == 1) {
        sky = mix(sky, sky * 1.06 + vec3(0.03), 0.6);
    } else if (SKY_PRESET == 2) {
        sky = mix(sky, sky * 0.92 + vec3(0.01), 0.7);
    }

    gl_FragData[0] = vec4(sky, 1.0);
}