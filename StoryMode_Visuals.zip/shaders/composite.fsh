#version 120
/* DRAWBUFFERS:0 */

// === inlined lib.glsl ===
/*
============================================================================
 STORY MODE VISUALS — shared library
 Telltale "Minecraft: Story Mode" style renderer for Iris / Oculus 1.20.1
 ----------------------------------------------------------------------------
 Contents:
   hashes & 3D value noise        (procedural sky / clouds / water jitter)
   RGB <-> HSV, smoothstep curves (time-of-day color grading)
   gamma helpers, SDR tonemapper  (cinematic contrast)
   14 hardcoded BIOME FOG PROFILES with smooth crossfade weights
   procedural star field
   Story Mode LUT (grade)         (warm high-contrast Season-1 grade)
============================================================================
*/

// ---------------------------------------------------------------- hashes
float hash12(vec2 p) {
    return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453123);
}
float hash13(vec3 p) {
    return fract(sin(dot(p, vec3(127.1, 311.7, 74.7))) * 43758.5453123);
}
vec3  hash33(vec3 p) {
    return vec3(hash13(p), hash13(p + 91.7), hash13(p + 213.3));
}
vec2  hash22(vec2 p) {
    return vec2(hash12(p), hash12(p + 91.7));
}

// ------------------------------------------------------------- 3D noise
float vnoise(vec3 p) {
    vec3 i = floor(p);
    vec3 f = fract(p);
    vec3 u = f * f * (3.0 - 2.0 * f);
    return mix(
        mix(mix(hash13(i + vec3(0,0,0)), hash13(i + vec3(1,0,0)), u.x),
            mix(hash13(i + vec3(0,1,0)), hash13(i + vec3(1,1,0)), u.x), u.y),
        mix(mix(hash13(i + vec3(0,0,1)), hash13(i + vec3(1,0,1)), u.x),
            mix(hash13(i + vec3(0,1,1)), hash13(i + vec3(1,1,1)), u.x), u.y),
        u.z);
}
float fbm3(vec3 p) {
    return vnoise(p) * 0.55 + vnoise(p * 2.13) * 0.30 + vnoise(p * 4.71) * 0.15;
}

// ------------------------------------------------------------- color ops
vec3 rgb2hsv(vec3 c) {
    vec4 K = vec4(0.0, -1.0 / 3.0, 2.0 / 3.0, -1.0);
    vec4 p = mix(vec4(c.bg, K.wz), vec4(c.gb, K.xy), step(c.b, c.g));
    vec4 q = mix(vec4(p.xyw, c.r), vec4(c.r, p.yzx), step(p.x, c.r));
    float d = q.x - min(q.w, q.y);
    float e = 1.0e-10;
    return vec3(abs(q.z + (q.w - q.y) / (6.0 * d + e)), d / (q.x + e), q.x);
}
vec3 hsv2rgb(vec3 c) {
    vec3 rgb = clamp(abs(mod(c.x * 6.0 + vec3(0.0, 4.0, 2.0), 6.0) - 3.0) - 1.0, 0.0, 1.0);
    return c.z * mix(vec3(1.0), rgb, c.y);
}

// smootherstep + gamma helpers
float sstep(float a, float b, float x) {
    x = clamp((x - a) / max(b - a, 1e-5), 0.0, 1.0);
    return x * x * (3.0 - 2.0 * x);
}
vec3 toLinear(vec3 c)  { return pow(max(c, vec3(0.0)), vec3(2.2)); }
vec3 toGamma(vec3 c)   { return pow(max(c, vec3(0.0)), vec3(1.0 / 2.2)); }

// ------------------------------------------------------------- SDR grade
vec3 sdrTonemap(vec3 c) {
    vec3 t = toLinear(c);
    t = t * (2.51 * t + vec3(0.03)) / (t * (2.43 * t + vec3(0.59)) + vec3(0.14)); // ACES fit
    return toGamma(clamp(t, 0.0, 1.0));
}

// ------------------------------------------------ Story Mode LUT (Season 1)
// High saturation, warm highlights, teal-purple shadow split.
vec3 grade(vec3 c, float sat) {
    float luma = dot(c, vec3(0.2126, 0.7152, 0.0722));
    vec3 graded = mix(vec3(luma), c, sat);
    graded *= vec3(1.02, 1.00, 0.97);
    graded = pow(graded, vec3(1.04, 1.00, 0.96));              // warm lift
    float shad = sstep(1.0, 0.0, luma);
    graded += vec3(-0.015, 0.004, 0.028) * shad;               // cool shadows
    float hi = sstep(0.78, 1.0, luma);
    graded += vec3(0.022, 0.010, -0.006) * hi;                 // warm highlights
    return sdrTonemap(graded);
}

// ------------------------------------------------------------------ stars
float starLayer(vec3 dir, float density, float twinkle) {
    vec3 p = normalize(dir + 0.0001) * 160.0;
    vec3 id = floor(p);
    vec3 f = fract(p) - 0.5;
    float star = 0.0;
    for (int i = 0; i < 3; i++) {
        vec3 o = vec3(float(i), float(i * 2 + 1), float(i * 3 + 2));
        vec3 h = hash33(id + o) - 0.5;
        float d = length(f - h * 1.4);
        star += smoothstep(0.06, 0.0, d) * step(density, hash13(id + o + 7.0));
    }
    float tw = 0.75 + 0.25 * sin(twinkle * 0.6 + hash13(id) * 6.283);
    return clamp(star * tw, 0.0, 1.0);
}

// --------------------------------------------------- procedural moon disk
vec3 moonGlow(vec3 dir, vec3 moonDir, float moonPhase, float size) {
    float disk = smoothstep(1.0 - size * 0.004, 1.0 - size * 0.001, dot(dir, moonDir));
    vec2 lp = dir.xy * 24.0;
    float crater = vnoise(vec3(lp * 1.7, 3.0)) * 0.12 + vnoise(vec3(lp * 5.0, 9.0)) * 0.05;
    float terminator = mix(1.0 - moonPhase, moonPhase, step(0.0, dir.x));
    float shade = clamp(terminator + crater, 0.0, 1.0);
    return vec3(1.0, 1.0, 0.97) * shade * (0.25 + 0.75 * disk);
}

// =================================================================
// BIOME FOG PROFILES - 14 hardcoded presets, smoothly crossfaded
// =================================================================
vec4 fogProfile(int id) {
    // .rgb = fog color, .a = fog density
    if (id == 0)  return vec4(0.31, 0.38, 0.48, 0.55); // plains - clean cyan-violet
    if (id == 1)  return vec4(0.28, 0.42, 0.40, 0.62); // forest - deep green
    if (id == 2)  return vec4(0.92, 0.66, 0.72, 0.60); // cherry - pink blossom haze
    if (id == 3)  return vec4(0.35, 0.60, 0.42, 0.72); // jungle - humid emerald
    if (id == 4)  return vec4(0.93, 0.72, 0.33, 0.46); // desert - golden heat-glare
    if (id == 5)  return vec4(0.85, 0.50, 0.25, 0.44); // badlands - rust glare
    if (id == 6)  return vec4(0.88, 0.72, 0.38, 0.52); // savanna - dry gold
    if (id == 7)  return vec4(0.28, 0.40, 0.27, 0.95); // swamp - thick mossy mist
    if (id == 8)  return vec4(0.62, 0.72, 0.88, 0.68); // snowy - crisp lavender
    if (id == 9)  return vec4(0.55, 0.66, 0.80, 0.66); // taiga - cool pine
    if (id == 10) return vec4(0.58, 0.60, 0.84, 0.60); // mountains - lavender fade
    if (id == 11) return vec4(0.28, 0.50, 0.68, 0.50); // ocean - blue abyss
    if (id == 12) return vec4(0.72, 0.56, 0.85, 0.70); // mushroom - spore haze
    return            vec4(0.30, 0.28, 0.22, 0.78);     // caves - pitch mist
}

// Continuous biome crossfade: weights for the nearest 8 voxel corners
void biomeWeights(vec3 pos, out float w[8], out ivec4 id[8]) {
    vec3 c = pos * 0.004 + 1000.0;               // per-biome = per-64-block cell
    vec3 f = fract(c);
    for (int k = 0; k < 8; k++) {
        vec3 o = vec3(float(k & 1), float((k >> 1) & 1), float((k >> 2) & 1));
        vec3 d = f - o;
        w[k] = (1.0 - abs(d.x)) * (1.0 - abs(d.y)) * (1.0 - abs(d.z));
        id[k] = ivec4(int(hash13(floor(c) + o) * 14.0), 0, 0, 0);
    }
}
// Continuous biome match: how much of the 8 nearest cells belong to one
// profile (used for aurora placement and desert heat shimmer).
float biomeMatch(vec3 pos, float target) {
    float w[8]; ivec4 id[8];
    biomeWeights(pos, w, id);
    float s = 0.0;
    for (int k = 0; k < 8; k++) {
        if (abs(float(id[k].x) - target) < 0.5) s += w[k];
    }
    return s;
}

vec4 sampledFog(vec3 pos) {
    float w[8]; ivec4 id[8];
    biomeWeights(pos, w, id);
    vec4 fog = vec4(0.0);
    float sum = 0.0;
    for (int k = 0; k < 8; k++) {
        vec4 p = fogProfile(id[k].x);
        fog += p * w[k];
        sum += w[k];
    }
    return fog / max(sum, 1e-4);
}

/*
  COMPOSITE: SSAO contact occlusion, per-biome Story Mode fog, desert heat
  shimmer, aurora overlay, sun/moon god rays and bloom.
  Every uniform used is declared locally - no reliance on loader injection.
*/

varying vec2 texcoord;

// Legacy MRT contract (DRAWBUFFERS:012 in the gbuffers passes):
//   gl_FragData[0] -> colortex0 (color)
//   gl_FragData[1] -> colortex1 (depth copy, cleared white by the loader)
//   gl_FragData[2] -> colortex2 (normals, sampled in final.fsh)
// colortex1 is declared here for completeness even though this program
// reads the loader-filled depth textures depthtex0/depthtex1 instead.
uniform sampler2D colortex0;
uniform sampler2D colortex1;
uniform sampler2D depthtex0;
uniform sampler2D depthtex1;

uniform mat4 gbufferProjection;
uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferModelView;
uniform mat4 gbufferModelViewInverse;

uniform vec3  cameraPosition;
uniform vec3  sunPosition;
uniform vec3  moonPosition;
uniform float viewWidth;
uniform float viewHeight;
uniform float frameTimeCounter;
uniform float sunAngle;
uniform float rainStrength;
uniform int   worldTime;

uniform float FOG_STR; //settings fog
uniform float MOONSHINE; //settings moonlight

vec3 getWorldPos(vec2 uv) {
    float depth = texture2D(depthtex0, uv).r;
    if (depth > 0.99999) return vec3(1000000.0);
    vec3 clip = vec3(uv * 2.0 - 1.0, depth * 2.0 - 1.0);
    vec4 world = gbufferProjectionInverse * vec4(clip, 1.0);
    world /= world.w;
    return world.xyz + cameraPosition;
}

void main() {
    vec2 uv = texcoord;
    vec3 scene = texture2D(colortex0, uv).rgb;
    vec3 pos = getWorldPos(uv);
    float d1 = texture2D(depthtex1, uv).r;

    // ==================== SSAO: dark contact lines where geometry meets ====
#ifdef SSAO
    if (pos.y < 1000000.0 && d1 < 0.9999) {
        float depth = d1;
        float occ = 0.0;
        float radius = 2.6 / max(depth * 900.0, 0.12);
        vec2 rnd = hash22(uv * vec2(viewWidth, viewHeight) + frameTimeCounter) * 6.283;
        mat2 rot = mat2(cos(rnd.x), -sin(rnd.x), sin(rnd.x), cos(rnd.x));
        for (int i = 0; i < 12; i++) {
            float a = (float(i) / 12.0) * 6.2831;
            float rr = radius * (0.4 + 0.6 * hash12(vec2(float(i), 3.0)));
            vec2 dir = rot * vec2(cos(a), sin(a)) * rr;
            float sd = texture2D(depthtex1, uv + dir).r;
            float diff = depth - sd;
            float dist = length(dir * vec2(viewWidth / 2.0, viewHeight / 2.0)) / 160.0;
            occ += clamp(diff * 2400.0 - dist * 0.06, 0.0, 1.0);
        }
        scene *= 1.0 - clamp(occ / 12.0, 0.0, 1.0) * 0.65;
    }
#endif

    // ==================== BIOME FOG (Story Mode per-area mist) ==============
    float dist = length(pos - cameraPosition);
    vec4 fog = sampledFog(pos);
    float nightMul = (sunAngle < 0.45) ? 0.6 : 1.0;
    float fogF = 1.0 - exp(-fog.a * nightMul * FOG_STR * dist * 0.0022);
    scene = mix(scene, fog.rgb, clamp(fogF, 0.0, 0.94));

    // ==================== DESERT HEAT SHIMMER ================================
#ifdef HEAT_SHIMMER
    float desertW = biomeMatch(pos, 4.0) + biomeMatch(pos, 5.0) * 0.7;
    float glare = desertW * (1.0 - rainStrength) * sstep(0.0, 0.5, sunAngle);
    if (glare > 0.01) {
        vec2 shimmer = vec2(vnoise(vec3(pos.x * 0.35, pos.y * 0.35, frameTimeCounter * 0.9)),
                            vnoise(vec3(pos.z * 0.35, pos.y * 0.35, frameTimeCounter * 0.9))) - 0.5;
        shimmer *= 0.004 * glare * smoothstep(8.0, 90.0, dist);
        vec3 shifted = texture2D(colortex0, uv + shimmer).rgb;
        scene = mix(scene, shifted, 0.6 * glare);
        scene += vec3(1.0, 0.82, 0.55) * glare * 0.05;
    }
#endif

    // ==================== AURORA OVERLAY (cold biomes) =======================
#ifdef AURORA
    float auroraW = biomeMatch(pos, 8.0) + biomeMatch(pos, 9.0) * 0.8;
    if (auroraW > 0.01 && sunAngle < 0.45 && rainStrength < 0.8) {
        vec3 dir = normalize(pos - cameraPosition);
        float aDir = dot(normalize(dir.xz + 0.0001), vec2(0.3, 0.95));
        float ribbon = smoothstep(0.2, 0.9, fbm3(vec3(aDir * 3.5, dir.y * 4.0 - frameTimeCounter * 0.06)));
        float band = smoothstep(0.0, 0.55, dir.y) * smoothstep(0.85, 0.55, dir.y);
        float aur = ribbon * band * auroraW * MOONSHINE * 0.6;
        scene += vec3(0.15, 0.85, 0.55) * aur;
        scene += vec3(0.65, 0.25, 0.75) * aur * 0.5;
    }
#endif

    // ==================== GOD RAYS ==========================================
#ifdef GODRAYS
    if (rainStrength < 0.9) {
        vec3 celest = (sunAngle < 0.45) ? normalize(moonPosition) : normalize(sunPosition);
        vec4 clip = gbufferProjection * gbufferModelViewInverse * vec4(celest * 200.0, 1.0);
        vec2 sunUv = clip.xy / clip.w * 0.5 + 0.5;
        if (clip.w > 0.0 && clamp(sunUv, vec2(0.0), vec2(1.0)) == sunUv) {
            vec2 dirToSun = (sunUv - uv) * 0.028;
            vec3 rays = vec3(0.0);
            vec2 su = uv;
            for (int i = 0; i < 14; i++) {
                su += dirToSun;
                float d = texture2D(depthtex1, clamp(su, 0.002, 0.998)).r;
                float luma = dot(texture2D(colortex0, clamp(su, 0.002, 0.998)).rgb, vec3(0.299, 0.587, 0.114));
                float visible = step(d, 0.99999);
                rays += vec3(luma) * pow(max(1.0 - float(i) / 14.0, 0.0), 2.0) * visible;
            }
            vec3 rayCol = (sunAngle < 0.45) ? vec3(0.55, 0.7, 1.0) : vec3(1.0, 0.82, 0.6);
            scene += rayCol * rays * 0.10 * (1.0 - rainStrength);
        }
    }
#endif

    // ==================== BLOOM =============================================
#ifdef BLOOM
    vec3 bloom = vec3(0.0);
    float bweights = 0.0;
    for (int x = -2; x <= 2; x++) {
        for (int y = -2; y <= 2; y++) {
            vec2 o = (vec2(float(x), float(y)) * 2.0 + 1.0) / vec2(viewWidth, viewHeight);
            vec3 s = texture2D(colortex0, uv + o).rgb;
            float w = 1.0 / (1.0 + dot(vec2(x, y), vec2(x, y)));
            float l = dot(s, vec3(0.299, 0.587, 0.114));
            bloom += s * max(l - 0.75, 0.0) * w;
            bweights += w;
        }
    }
    bloom /= max(bweights, 1e-5);
    scene += bloom * 0.6;
#endif

    gl_FragData[0] = vec4(scene, 1.0);
}